public class FinancialForecasting {

    // Recursive method to calculate future value
    public static double forecastFutureValue(double initialValue, double growthRate, int periods) {
        // Base case: when periods is 0, return the initial value
        if (periods == 0) {
            return initialValue;
        }
        // Recursive case: calculate the value for the next period
        return forecastFutureValue(initialValue, growthRate, periods - 1) * (1 + growthRate);
    }

    public static void main(String[] args) {
        double initialValue = 1000.0; // Initial value of the financial data
        double growthRate = 0.05;     // 5% growth rate
        int periods = 5;              // Predicting for 5 periods into the future

        double futureValue = forecastFutureValue(initialValue, growthRate, periods);
        System.out.println("The predicted future value after " + periods + " periods is: " + futureValue);
    }
}
