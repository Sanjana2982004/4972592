import java.util.HashMap;
import java.util.Map;

public class Inventory {
    private Map<String, Product> products;

    public Inventory() {
        this.products = new HashMap<>();
    }

    public void addProduct(Product product) {
        if (products.containsKey(product.getProductId())) {
            System.out.println("Product with ID " + product.getProductId() + " already exists.");
        } else {
            products.put(product.getProductId(), product);
            System.out.println("Product " + product.getProductName() + " added.");
        }
    }

    public void updateProduct(String productId, Integer newQuantity, Double newPrice) {
        Product product = products.get(productId);
        if (product != null) {
            if (newQuantity != null) {
                product.setQuantity(newQuantity);
            }
            if (newPrice != null) {
                product.setPrice(newPrice);
            }
            System.out.println("Product " + productId + " updated.");
        } else {
            System.out.println("Product with ID " + productId + " not found.");
        }
    }

    public void deleteProduct(String productId) {
        if (products.containsKey(productId)) {
            products.remove(productId);
            System.out.println("Product " + productId + " deleted.");
        } else {
            System.out.println("Product with ID " + productId + " not found.");
        }
    }

    public void displayProducts() {
        for (Product product : products.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        System.out.println("--------ABOUT INVENTORY MANAGEMENT SYSTEM--------");
        // Adding products
        Product product1 = new Product("P1", "Smartphone", 100, 10000.0);
        Product product2 = new Product("P2", "Watch", 150, 500.0);
        inventory.addProduct(product1);
        inventory.addProduct(product2);

        // Displaying products
        inventory.displayProducts();

        // Updating a product
        inventory.updateProduct("P1", 8, null);

        // Displaying products after update
        inventory.displayProducts();

        // Deleting a product
        inventory.deleteProduct("P2");

        // Displaying products after deletion
        inventory.displayProducts();
    }
}
