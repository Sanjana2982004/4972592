public class OrderSortingDemo {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("O001", "Alice", 250.0),
            new Order("O002", "Bob", 300.0),
            new Order("O003", "Charlie", 150.0),
            new Order("O004", "Diana", 200.0),
            new Order("O005", "Eve", 350.0)
        };

        // Bubble Sort
        System.out.println("------Bubble Sort-----------");
        System.out.println("Bubble Sort:");
        BubbleSort.sortOrdersByTotalPrice(orders);
        for (Order order : orders) {
            System.out.println(order);
        }

        // Quick Sort
        System.out.println("-------Quick Sort-------");
        System.out.println("\nQuick Sort:");
        QuickSort.sortOrdersByTotalPrice(orders);
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}
