public class TaskManagementSystem {
    public static void main(String[] args) {
        TaskManager manager = new TaskManager();

        // Adding tasks
        manager.addTask("T001", "Design Database", "In Progress");
        manager.addTask("T002", "Implement API", "Not Started");
        manager.addTask("T003", "Write Documentation", "In Progress");

        // Traversing tasks
        System.out.println("All Tasks:");
        manager.traverseTasks();

        // Searching for a task
        System.out.println("\nSearching for Task T002:");
        Task task = manager.searchTask("T002");
        if (task != null) {
            System.out.println(task);
        } else {
            System.out.println("Task not found.");
        }

        // Deleting a task
        System.out.println("\nDeleting Task T003:");
        boolean deleted = manager.deleteTask("T003");
        if (deleted) {
            System.out.println("Task T003 deleted successfully.");
        } else {
            System.out.println("Task T003 not found.");
        }

        // Traversing tasks after deletion
        System.out.println("\nAll Tasks after deletion:");
        manager.traverseTasks();
    }
}
