class TaskManager {
    private Task head;

    public TaskManager() {
        this.head = null;
    }

    // Add a new task at the end of the list
    public void addTask(String taskId, String taskName, String status) {
        Task newTask = new Task(taskId, taskName, status);
        if (head == null) {
            head = newTask;
        } else {
            Task current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newTask;
        }
    }

    // Search for a task by taskId
    public Task searchTask(String taskId) {
        Task current = head;
        while (current != null) {
            if (current.taskId.equals(taskId)) {
                return current;
            }
            current = current.next;
        }
        return null; // Task not found
    }

    // Traverse and display all tasks
    public void traverseTasks() {
        Task current = head;
        while (current != null) {
            System.out.println(current);
            current = current.next;
        }
    }

    // Delete a task by taskId
    public boolean deleteTask(String taskId) {
        if (head == null) {
            return false; // List is empty
        }
        if (head.taskId.equals(taskId)) {
            head = head.next;
            return true; // Task deleted
        }
        Task current = head;
        while (current.next != null) {
            if (current.next.taskId.equals(taskId)) {
                current.next = current.next.next;
                return true; // Task deleted
            }
            current = current.next;
        }
        return false; // Task not found
    }
}
