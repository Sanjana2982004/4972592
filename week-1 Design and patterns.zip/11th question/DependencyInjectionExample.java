public class DependencyInjectionExample {
    public static void main(String[] args) {
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        // Inject repository into service
        CustomerService customerService = new CustomerService(customerRepository);

        // Find customer by ID
        Customer customer = customerService.findCustomerById("1");
        System.out.println(customer);
    }
}